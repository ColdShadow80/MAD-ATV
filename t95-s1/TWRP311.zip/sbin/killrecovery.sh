#!/sbin/sh
/sbin/busybox mkdir -p /system/bin
/sbin/busybox mkdir -p /external_sd
/sbin/busybox killall adbd && /sbin/stop adbd & /sbin/start adbd
/sbin/busybox killall -9 recovery
#/sbin/busybox killall -9 updater
/sbin/busybox rm /tmp/openrecoveryscript
exit 0
